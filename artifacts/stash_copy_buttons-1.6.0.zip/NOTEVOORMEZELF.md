Builden -> `buildstash` is voldoende om alles te fixen.
