Builden -> `buildstash` is voldoende om alles te fixen.

Let op: chrome heeft manifest v3 nodig, Firefox v2!!