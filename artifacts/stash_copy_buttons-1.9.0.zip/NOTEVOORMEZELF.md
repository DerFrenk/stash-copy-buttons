Builden -> `buildstash` is voldoende om alles te fixen.

LET OP: BUILDSTASHCOMMANDO IS GEWIJZIGD EN MOET VOLGENDE KEER GETEST

Stappen:
 - In manifest en package.json
 - In het manifest de versie op 2 zetten
 - npm run build
 - Uploaden naar Chrome store
 - EUH opeens niet: ~In het manifest de versie op 3 zetten~
 - `buildstash`
 - Nieuwe XPI toevoegen aan de updates.json
 - Nieuwe artifacts en gewijzigde files committen
