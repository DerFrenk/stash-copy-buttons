Builden -> `npm run buildAndSign` is voldoende om alles te fixen.

Stappen:
 - In manifest en package.json versie ophogen
 - `buildstash`
 - Nieuwe XPI toevoegen aan de updates.json
 - Nieuwe artifacts en gewijzigde files committen
